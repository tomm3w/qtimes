// function toggleScreens() {
//   $(".waittime .btn--orng").click(function() {
//     $(".waittime").hide();
//     $(".waitlist").show();
//   });
//   $(".waitlist .btn--green").click(function() {
//     $(".waitlist").hide();
//     $(".thankyou").show();
//   });
// }
// toggleScreens();

